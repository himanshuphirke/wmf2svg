package net.arnx.wmf2svg.gdi;

public interface GdiObject {
}
